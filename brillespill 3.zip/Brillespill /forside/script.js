const burgerEL = document.
       querySelector('.fa-bars')

       const navEL = document.querySelector
       ('.nav')

       burgerEL.addEventListener('click',showNav)

       function showNav(){
        navEL.classList.toggle('show')
       }

       