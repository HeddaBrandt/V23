document.addEventListener('DOMContentLoaded', () => {

// Liste over alle kortene
const cardArray = [
    { name: "thomas", image: './images/bilde1.png' },
    { name: "thomas", image: './images/bilde1.png' },
    { name: "marcus", image: './images/bilde2.png' },
    { name: "marcus", image: './images/bilde2.png' },
    { name: "laurits", image: './images/bilde3.png' },
    { name: "laurits", image: './images/bilde3.png' },
    { name: "rohan", image: './images/bilde4.png' },
    { name: "rohan", image: './images/bilde4.png' },
    { name: "didrik", image: './images/bilde5.png' },
    { name: "didrik", image: './images/bilde5.png' },
    { name: "sara", image: './images/bilde6.png' },
    { name: "sara", image: './images/bilde6.png' }
/*     { name: "hedda", image: 'images/bilde7.png' },
    { name: "hedda", image: 'images/bilde7.png' }, */
/*     { name: "mie", image: 'images/bilde8.png' },
    { name: "mie", image: 'images/bilde8.png' } */]
    // skal man ha ' eller ""
// stokkker om lista
cardArray.sort(() => 0.5 - Math.random())



const grid = document.querySelector('.grid')
const resultDisplay = document.querySelector('#result')
let cardsChosen = []
let cardsChosenId = []
let cardsWon = []



// Lage brettet
function createBoard() {
    for (let i = 0; i < cardArray.length; i++) {
        let card = document.createElement('img')
        card.setAttribute('src', 'images/brille.png')
        card.setAttribute('data-id', i)
        card.addEventListener('click', flipCard)
        grid.appendChild(card)
    }
}


function checkForMatch() {
    //if (index IKKE er eksakt like)
        // 

    let cards = document.querySelectorAll('img')
    // Henter ut 1 og 2 kort
    const optionOneId = cardsChosenId[0]
    const optionTwoId = cardsChosenId[1]
    console.log(optionOneId, optionTwoId)
    
        if (cardsChosen[0] === cardsChosen[1]){
            cards[optionOneId].setAttribute('src', 'images/white.png')
            cards[optionTwoId].setAttribute('src', 'images/white.png')
            cardsWon.push(cardsChosen)
        } else {
            cards[optionOneId].setAttribute('src', 'images/brille.png')
            cards[optionTwoId].setAttribute('src', 'images/brille.png')
        }
        
        cardsChosen = []
        cardsChosenId = []
        resultDisplay.textContent = cardsWon.length
        // funnet alle kortene
        if (cardsWon.length === cardArray.length/2) {
            resultDisplay.textContent = 'congratsz'
        }
}


function flipCard() {
    let cardId = this.getAttribute('data-id')
    // legger til tallet i lista
    cardsChosen.push(cardArray[cardId].name)
    cardsChosenId.push(cardId)
    if (cardsChosenId[0] != cardsChosenId[1]){ 
        this.setAttribute('src', cardArray[cardId].image)
        if (cardsChosen.length === 2) {
            // lager litt tidsmellomrom 
            setTimeout(checkForMatch, 500)
        }
    }else{
        // la den til i lista istad, men fjerner den umiddelbart igjen
        cardsChosen.pop()
        cardsChosenId.pop()
    }
}
createBoard()

})

